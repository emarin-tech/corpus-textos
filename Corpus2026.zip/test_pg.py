import psycopg2

conn = psycopg2.connect(
    dbname="db_corpus_2026",
    user="user_corpus_2026",
    password="1p&huv9$vvbUqe9drA8FJ!X*GhyFrpgDxdqUFk3H",
    host="localhost",
    port="5433"
)

print("Conexión exitosa")
conn.close()
